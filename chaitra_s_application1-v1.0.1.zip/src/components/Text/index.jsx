import React from "react";

const sizeClasses = {
  txtFigtreeRegular14BlueA200: "font-figtree font-normal",
  txtNunitoSemiBold16: "font-nunito font-semibold",
  txtFigtreeSemiBold14Gray900: "font-figtree font-semibold",
  txtNunitoSemiBold24: "font-nunito font-semibold",
  txtFigtreeSemiBold24: "font-figtree font-semibold",
  txtFigtreeRegular14: "font-figtree font-normal",
  txtNunitoSemiBold16Gray500: "font-nunito font-semibold",
  txtFigtreeSemiBold14: "font-figtree font-semibold",
  txtFigtreeRegular16: "font-figtree font-normal",
  txtNunitoSemiBold16Black90087: "font-nunito font-semibold",
};

const Text = ({ children, className = "", size, as, ...restProps }) => {
  const Component = as || "p";

  return (
    <Component
      className={`text-left ${className} ${size && sizeClasses[size]}`}
      {...restProps}
    >
      {children}
    </Component>
  );
};

export { Text };
